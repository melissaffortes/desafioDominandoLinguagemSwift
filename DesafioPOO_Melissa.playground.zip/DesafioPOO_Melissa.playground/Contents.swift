import UIKit

//Coleções

var AppleProductst: [String] = ["iPhone", "Apple Watch", "HomePod"]
print("A lista de compras contém \(AppleProductst.count) itens.")

if AppleProductst.isEmpty {
    print("Você precisa comprar produtos apple")
} else {
    print("Sua lista de produtos apple contém \(AppleProductst)")
}

AppleProductst.append("Vision Pro")
AppleProductst[0] = "Airport Express"

print("Sua nova lista de produtos apple contém \(AppleProductst)")

//Controle de Fluxo

let myMostUsedAppleProduct = "Apple Watch"
switch myMostUsedAppleProduct {
case "HomePod":
    print("Ótimo para conversar com a Siri.")
case "iPhone", "iPad", "iPod":
    print("Pefeitos para o iMessage")
case let appl where appl.hasPrefix("Apple"):
    print("\(appl) ótimo para suas atividades fisícas")
default:
    print("Qualquer produto é uma excelente .")
}


//Classes

class Tech {
    
    var year: Int?
    var model: String?
    var OSVersion: String?
    
    
    func checkUpdate() {
        print("A versão do iOS deverá ser verificada em ajustes e depois sobre")
       }
    
}


let tech = Tech()
tech.year = 2022
tech.model = "iPhone 14 Pro Max"
tech.OSVersion = "iOS 17 Beta7"
tech.checkUpdate()


//Encapsulamento

class CanIAfordTheNewIphone {
    let iPhonePrice: Double!
    let MyBankAccount: Double!
    
    public var result: Double?
    
    init(iPhonePrice: Double, MyBankAccount: Double) {
        self.iPhonePrice = iPhonePrice
        self.MyBankAccount = MyBankAccount
    }
    
    func Affordable() {
        result = MyBankAccount - iPhonePrice
    }
    
    
    func CanI(){
        if result ?? 0 >= 0 {
            print("Você poder comprar o novo iPhone e vão sobrar: R$\(result ?? 0)")
        } else {
            print("Você está pobre")
        }
    }
}
let Math = CanIAfordTheNewIphone(iPhonePrice: 11500, MyBankAccount: 12500)
Math.Affordable()
Math.CanI()

//Herança

class myCloset {
    var pants: String
    var shirt: String
    var dresses: String
    var shoes: String
    
    init(pants: String, shirt: String, dresses: String, shoes: String) {
        self.pants = pants
        self.shirt = shirt
        self.dresses = dresses
        self.shoes = shoes
    }
    
    func BeautyAppliance(MakeUp: String) {
        print("Fez maquiagem? \(MakeUp)")
    }
    
}

class Party: myCloset {

}

let Birthday = Party(pants: "jeans", shirt: "blue", dresses: "none", shoes: "High Heels")
print(Birthday.pants)

Birthday.BeautyAppliance(MakeUp: "Only at the eyes")

//Polimorfismo

class MakeUp: myCloset {
    
    override  func BeautyAppliance(MakeUp: String) {
        print("Fez maquiagem? \(MakeUp)")
    }
}

let MakeUoBeauty = MakeUp(pants: "jeans", shirt: "blue", dresses: "none", shoes: "High Heels")
MakeUoBeauty.BeautyAppliance(MakeUp: "No MakeUp At all")

//Funções e Cloures

func FavoriteTechDevice(device: String, brand: String) -> String {
    return "My favorite device is \(device), from \(brand)."
}

FavoriteTechDevice(device: "DSLR", brand: "Nikon")


let FavAppleProductst = ["iPhone", "Apple Watch", "HomePod"]
func backward(_ s1: String, _ s2: String) -> Bool {
    return s1 > s2
}
var reversedNames = FavAppleProductst.sorted(by: backward)


//Enum

enum ComputerLanguage {
    case C, Swift, Java, React
    
    func Favlanguage() -> String {
        switch self {
        case .C:
            return "C is how things started with Swift"
        case .Swift:
            return "Favorite Apple Language"
        case .Java:
            return "Very popular language"
        case .React:
            return "The favorite between the hibrids"
        }
    }
}
let java = ComputerLanguage.Java
let javaLanguage = java.Favlanguage()

//Structs

struct Student {

  var name = " "
  var age = 0
}


var studentRJ = Student()
studentRJ.name = "Melissa"

print("Name: \(studentRJ.name) and Age: \( studentRJ.age) ")

//Concorrências

func fetchContact(from ContactApp: String) async -> Int {
    if ContactApp == "Melissa" {
        return 02
    }
    return 404
}

func fetchUsername(from ContactApp: String) async -> String {
    let userId = await fetchContact(from: ContactApp)
    if userId == 02 {
        return "Melissa"
    }
    return "Not in the guest list"
}
