import UIKit

//Protocolo

protocol StudentsGrade: CustomStringConvertible {
    var name: String { get }
    var finalGrade: Int { get }
    var Certified: Bool { get }
}

protocol Grade {
    var topgrade: Int { get }
}

struct StudentHighSchool: StudentsGrade, Grade {
    let name: String
    var finalGrade: Int
    var description: String
    var Certified: Bool = true
    var topgrade: Int {
        4 * finalGrade/2
    }
}

let StudentRJ = StudentHighSchool(name: "Melissa", finalGrade: 8, description: "math")
print("A aluna \(StudentRJ.name) teve a nota de \(StudentRJ.topgrade)")

extension StudentsGrade {
    var Certified: Bool { self is Grade }
}

struct StudentUS: StudentsGrade {
    var finalGrade: Int
    var description: String
    let name: String
    var Certified: Bool = true
}

let anotherStudent = StudentUS(finalGrade: 9, description: "biology", name: "Clara")
print("\(anotherStudent.name) se certificou no curso? \(anotherStudent.Certified ? "Sim!" : "Não!")")


